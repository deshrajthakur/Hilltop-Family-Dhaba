// Update these values with the dhaba's real details before publishing.
window.DHABA = {
  phone: "", // Example: "+919876543210"
  whatsapp: "", // digits only, country code included; example "919876543210"
  email: "", // email address for contact form
  address: "Hilltop Family Dhaba, Himachal Pradesh, India",
  mapsUrl: "" // Optional Google Maps directions URL
};

document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav-links");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Close navigation menu" : "Open navigation menu");
      toggle.textContent = open ? "×" : "☰";
    });
    nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
      nav.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
      toggle.textContent = "☰";
    }));
  }

  document.querySelectorAll("[data-phone]").forEach(el => {
    if (window.DHABA.phone) el.href = "tel:" + window.DHABA.phone;
    else { el.href = "contact.html"; el.title = "Add your phone number in script.js"; }
  });
  document.querySelectorAll("[data-whatsapp]").forEach(el => {
    if (window.DHABA.whatsapp) el.href = "https://wa.me/" + window.DHABA.whatsapp;
    else { el.href = "contact.html"; el.title = "Add your WhatsApp number in script.js"; }
  });
  document.querySelectorAll("[data-address]").forEach(el => el.textContent = window.DHABA.address);
  document.querySelectorAll("[data-maps]").forEach(el => {
    if (window.DHABA.mapsUrl) el.href = window.DHABA.mapsUrl;
    else el.href = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(window.DHABA.address);
  });

  // Menu filtering and search
  const menuCards = [...document.querySelectorAll("[data-menu-item]")];
  let activeCategory = "all";
  const search = document.querySelector("#menu-search");
  const filterCards = () => {
    const term = (search?.value || "").trim().toLowerCase();
    menuCards.forEach(card => {
      const categoryMatch = activeCategory === "all" || card.dataset.category === activeCategory;
      const textMatch = card.textContent.toLowerCase().includes(term);
      card.hidden = !(categoryMatch && textMatch);
    });
    const empty = document.querySelector("#menu-empty");
    if (empty) empty.hidden = menuCards.some(card => !card.hidden);
  };
  document.querySelectorAll("[data-filter]").forEach(btn => btn.addEventListener("click", () => {
    activeCategory = btn.dataset.filter;
    document.querySelectorAll("[data-filter]").forEach(b => b.classList.toggle("active", b === btn));
    filterCards();
  }));
  if (search) search.addEventListener("input", filterCards);

  // Gallery lightbox
  const lightbox = document.querySelector(".lightbox");
  if (lightbox) {
    const close = () => { lightbox.classList.remove("open"); lightbox.setAttribute("aria-hidden", "true"); };
    document.querySelectorAll("[data-gallery]").forEach(item => item.addEventListener("click", () => {
      lightbox.querySelector(".lightbox-art").textContent = item.dataset.emoji || "🍲";
      lightbox.querySelector(".lightbox-title").textContent = item.dataset.title || "Hilltop Family Dhaba";
      lightbox.classList.add("open"); lightbox.setAttribute("aria-hidden", "false");
      lightbox.querySelector("button").focus();
    }));
    lightbox.querySelector("button").addEventListener("click", close);
    lightbox.addEventListener("click", e => { if (e.target === lightbox) close(); });
    document.addEventListener("keydown", e => { if (e.key === "Escape") close(); });
  }

  // Contact form: GitHub Pages is static, so open the visitor's email app.
  const form = document.querySelector("#contact-form");
  if (form) form.addEventListener("submit", e => {
    e.preventDefault();
    const status = document.querySelector("#form-status");
    if (!form.reportValidity()) return;
    if (!window.DHABA.email) {
      status.textContent = "The form is ready, but the restaurant email is not set yet. Add it in script.js before publishing.";
      status.style.color = "#9b3c22";
      return;
    }
    const data = new FormData(form);
    const subject = encodeURIComponent("Website enquiry - Hilltop Family Dhaba");
    const body = encodeURIComponent(
      "Name: " + data.get("name") + "\nPhone: " + data.get("phone") +
      "\nTopic: " + data.get("topic") + "\n\nMessage:\n" + data.get("message")
    );
    status.textContent = "Opening your email app to send the message…";
    window.location.href = "mailto:" + window.DHABA.email + "?subject=" + subject + "&body=" + body;
  });

  const year = document.querySelector("[data-year]");
  if (year) year.textContent = new Date().getFullYear();
});
